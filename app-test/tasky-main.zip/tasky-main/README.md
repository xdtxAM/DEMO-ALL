# tasky
This is a task management app

# 博客地址：

入门Electron，手把手教你编写完整实用案例： https://juejin.cn/post/6974192432443293726

Electron应用的打包和自动更新： https://juejin.cn/post/6980105328801087518
